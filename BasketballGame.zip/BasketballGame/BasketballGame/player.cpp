﻿
#include "player.h"
#include <QDataStream>
#pragma execution_character_set("utf-8")

Player::Player()
    : number(0), age(0), threePointers(0), rebounds(0), dunks(0), steals(0)
{
}

// 修改得分计算规则
int Player::calculateTotalScore() const
{
    // 新的得分规则：
    // 三分球：3分/个
    // 扣篮：2分/次
    // 篮板球和抢断：不得分
    return threePointers * 3 + dunks * 2;
}

QDataStream &operator<<(QDataStream &out, const Player &player)
{
    out << player.number << player.name << player.age
        << player.threePointers << player.rebounds << player.dunks << player.steals;
    return out;
}

QDataStream &operator>>(QDataStream &in, Player &player)
{
    in >> player.number >> player.name >> player.age
       >> player.threePointers >> player.rebounds >> player.dunks >> player.steals;
    return in;
}
