﻿#ifndef GAMEINFOTABLE_H
#define GAMEINFOTABLE_H

#include <QList>
#include <QString>
#include <QMap>
#include "game.h"

class GameInfoTable
{
public:
    GameInfoTable();

    void AddGame(const Game& game);
    void RemoveGame(int index);
    void UpdateGame(int index, const Game& game);
    Game GetGame(int index) const;
    int GetGameCount() const;
    void SaveGamesToFile(const QString& fileName);
    void ReadGamesFromFile(const QString& fileName);

    // JSON 持久化
    void SaveGamesToJson(const QString& fileName);
    void ReadGamesFromJson(const QString& fileName);

    // 计算球员在所有比赛中的统计数据
    Player CalculatePlayerStats(int playerNumber) const;

    // 获取所有球员的统计数据
    QMap<int, Player> GetAllPlayerStats() const;

private:
    QList<Game> m_games;
};

#endif // GAMEINFOTABLE_H
