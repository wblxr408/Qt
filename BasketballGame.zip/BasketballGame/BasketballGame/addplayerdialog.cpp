﻿#include "addplayerdialog.h"
#include "ui_addplayerdialog.h"
#pragma execution_character_set("utf-8")

AddPlayerDialog::AddPlayerDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddPlayerDialog)
{
    ui->setupUi(this);
    setWindowTitle(tr("添加队员"));

    // 设置合理的数值范围（添加输入验证）
    ui->spinBoxNumber->setRange(1, 999);       // 队员编号范围1-999
    ui->spinBoxAge->setRange(10, 50);          // 年龄范围10-50
    ui->spinBoxThreePointers->setRange(0, 50); // 三分球范围0-50
    ui->spinBoxRebounds->setRange(0, 50);      // 篮板球范围0-50
    ui->spinBoxDunks->setRange(0, 50);         // 扣篮范围0-50
    ui->spinBoxSteals->setRange(0, 50);        // 抢断范围0-50
}

AddPlayerDialog::~AddPlayerDialog()
{
    delete ui;
}

int AddPlayerDialog::Number() const
{
    return ui->spinBoxNumber->value();
}

QString AddPlayerDialog::Name() const
{
    return ui->lineEditName->text();
}

int AddPlayerDialog::Age() const
{
    return ui->spinBoxAge->value();
}

int AddPlayerDialog::ThreePointers() const
{
    return ui->spinBoxThreePointers->value();
}

int AddPlayerDialog::Rebounds() const
{
    return ui->spinBoxRebounds->value();
}

int AddPlayerDialog::Dunks() const
{
    return ui->spinBoxDunks->value();
}

int AddPlayerDialog::Steals() const
{
    return ui->spinBoxSteals->value();
}
