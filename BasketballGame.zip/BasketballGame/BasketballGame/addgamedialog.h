﻿#ifndef ADDGAMEDIALOG_H
#define ADDGAMEDIALOG_H

#include <QDialog>
#include <QDateTime>
#include <QString>

namespace Ui {
class AddGameDialog;
}

class AddGameDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddGameDialog(QWidget *parent = nullptr);
    ~AddGameDialog();

    int GameId() const;
    QDateTime GameTime() const;
    QString Location() const;

private:
    Ui::AddGameDialog *ui;
};

#endif // ADDGAMEDIALOG_H
