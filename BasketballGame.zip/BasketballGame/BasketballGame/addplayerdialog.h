﻿#ifndef ADDPLAYERDIALOG_H
#define ADDPLAYERDIALOG_H

#include <QDialog>

namespace Ui {
class AddPlayerDialog;
}

class AddPlayerDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddPlayerDialog(QWidget *parent = nullptr);
    ~AddPlayerDialog();

    int Number() const;
    QString Name() const;
    int Age() const;
    int ThreePointers() const;
    int Rebounds() const;
    int Dunks() const;
    int Steals() const;

private:
    Ui::AddPlayerDialog *ui;
};

#endif // ADDPLAYERDIALOG_H
