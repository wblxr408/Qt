﻿#include "readonlydelegate.h"
#pragma execution_character_set("utf-8")

ReadOnlyDelegate::ReadOnlyDelegate(QObject *parent)
    : QItemDelegate(parent)
{
}

QWidget *ReadOnlyDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                                       const QModelIndex &index) const
{
    return nullptr;
}
