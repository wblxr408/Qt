﻿
#ifndef GAME_H
#define GAME_H

#include <QDateTime>
#include <QString>
#include <QList>
#include "player.h"

class Game
{
public:
    Game();

    int gameId;                 // 编号
    QDateTime gameTime;         // 比赛时间
    QString location;           // 比赛地点
    QList<Player> team1Players;
    QList<Player> team2Players;

    friend QDataStream &operator<<(QDataStream &out, const Game &game);
    friend QDataStream &operator>>(QDataStream &in, Game &game);
};

#endif // GAME_H
