﻿#include "gameinfotable.h"
#include <QFile>
#include <QDataStream>
#include <QMap>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#pragma execution_character_set("utf-8")


GameInfoTable::GameInfoTable()
{
}

void GameInfoTable::AddGame(const Game& game)
{
    m_games.append(game);
}

void GameInfoTable::RemoveGame(int index)
{
    if (index >= 0 && index < m_games.size())
        m_games.removeAt(index);
}

void GameInfoTable::UpdateGame(int index, const Game& game)
{
    if (index >= 0 && index < m_games.size())
        m_games[index] = game;
}

Game GameInfoTable::GetGame(int index) const
{
    if (index >= 0 && index < m_games.size())
        return m_games.at(index);
    return Game();
}

int GameInfoTable::GetGameCount() const
{
    return m_games.size();
}

void GameInfoTable::SaveGamesToFile(const QString& fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly)) {
        return;
    }

    QDataStream out(&file);
    out << m_games;
    file.close();
}

void GameInfoTable::ReadGamesFromFile(const QString& fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly)) {
        return;
    }

    QDataStream in(&file);
    in >> m_games;
    file.close();
}

static QJsonObject PlayerToJson(const Player &p)
{
    QJsonObject o;
    o["number"] = p.number;
    o["name"] = p.name;
    o["age"] = p.age;
    o["threePointers"] = p.threePointers;
    o["rebounds"] = p.rebounds;
    o["dunks"] = p.dunks;
    o["steals"] = p.steals;
    return o;
}

static Player PlayerFromJson(const QJsonObject &o)
{
    Player p;
    p.number = o.value("number").toInt();
    p.name = o.value("name").toString();
    p.age = o.value("age").toInt();
    p.threePointers = o.value("threePointers").toInt();
    p.rebounds = o.value("rebounds").toInt();
    p.dunks = o.value("dunks").toInt();
    p.steals = o.value("steals").toInt();
    return p;
}

void GameInfoTable::SaveGamesToJson(const QString& fileName)
{
    QJsonArray gamesArray;
    for (const Game &g : m_games) {
        QJsonObject go;
        go["gameId"] = g.gameId;
        go["gameTime"] = g.gameTime.toString("yyyy-MM-dd hh:mm");
        go["location"] = g.location;
        QJsonArray t1;
        for (const Player &p : g.team1Players) t1.append(PlayerToJson(p));
        QJsonArray t2;
        for (const Player &p : g.team2Players) t2.append(PlayerToJson(p));
        go["team1Players"] = t1;
        go["team2Players"] = t2;
        gamesArray.append(go);
    }
    QJsonDocument doc(gamesArray);
    QFile f(fileName);
    if (!f.open(QIODevice::WriteOnly)) return;
    f.write(doc.toJson(QJsonDocument::Compact));
    f.close();
}

void GameInfoTable::ReadGamesFromJson(const QString& fileName)
{
    QFile f(fileName);
    if (!f.open(QIODevice::ReadOnly)) return;
    QByteArray data = f.readAll();
    f.close();
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray()) return;
    QJsonArray arr = doc.array();
    m_games.clear();
    for (const QJsonValue &v : arr) {
        if (!v.isObject()) continue;
        QJsonObject go = v.toObject();
        Game g;
        g.gameId = go.value("gameId").toInt();
        g.gameTime = QDateTime::fromString(go.value("gameTime").toString(), "yyyy-MM-dd hh:mm");
        g.location = go.value("location").toString();
        QJsonArray t1 = go.value("team1Players").toArray();
        for (const QJsonValue &pv : t1) if (pv.isObject()) g.team1Players.append(PlayerFromJson(pv.toObject()));
        QJsonArray t2 = go.value("team2Players").toArray();
        for (const QJsonValue &pv : t2) if (pv.isObject()) g.team2Players.append(PlayerFromJson(pv.toObject()));
        m_games.append(g);
    }
}

Player GameInfoTable::CalculatePlayerStats(int playerNumber) const
{
    Player totalStats;
    totalStats.number = playerNumber;

    for (const Game& game : m_games) {
        // 检查球队1
        for (const Player& player : game.team1Players) {
            if (player.number == playerNumber) {
                totalStats.threePointers += player.threePointers;
                totalStats.rebounds += player.rebounds;
                totalStats.dunks += player.dunks;
                totalStats.steals += player.steals;
            }
        }

        // 检查球队2
        for (const Player& player : game.team2Players) {
            if (player.number == playerNumber) {
                totalStats.threePointers += player.threePointers;
                totalStats.rebounds += player.rebounds;
                totalStats.dunks += player.dunks;
                totalStats.steals += player.steals;
            }
        }
    }

    return totalStats;
}

QMap<int, Player> GameInfoTable::GetAllPlayerStats() const
{
    QMap<int, Player> playerStats;

    // 遍历所有比赛
    for (const Game& game : m_games) {
        // 处理球队1的球员
        for (const Player& player : game.team1Players) {
            if (!playerStats.contains(player.number)) {
                // 如果还没有这个球员的记录，创建一个
                Player newPlayer;
                newPlayer.number = player.number;
                newPlayer.name = player.name;
                newPlayer.age = player.age;
                playerStats[player.number] = newPlayer;
            }

            // 累加统计数据
            playerStats[player.number].threePointers += player.threePointers;
            playerStats[player.number].rebounds += player.rebounds;
            playerStats[player.number].dunks += player.dunks;
            playerStats[player.number].steals += player.steals;
        }

        // 处理球队2的球员
        for (const Player& player : game.team2Players) {
            if (!playerStats.contains(player.number)) {
                // 如果还没有这个球员的记录，创建一个
                Player newPlayer;
                newPlayer.number = player.number;
                newPlayer.name = player.name;
                newPlayer.age = player.age;
                playerStats[player.number] = newPlayer;
            }

            // 累加统计数据
            playerStats[player.number].threePointers += player.threePointers;
            playerStats[player.number].rebounds += player.rebounds;
            playerStats[player.number].dunks += player.dunks;
            playerStats[player.number].steals += player.steals;
        }
    }

    return playerStats;
}
