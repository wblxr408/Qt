﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QMenu>
#include <QAction>
#include <QItemSelection>
#include <QLineEdit>
#include "gameinfotable.h"
#include "readonlydelegate.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // 显示
    void ShowGameList(); // 场次列表
    void ShowPlayerList(int gameIndex); // 特定场次的队员列表
    void ShowPlayerStats(); // 队员统计
    void ShowPlayerTotalStats(); // 新增：显示队员所有场次合计得分

    // 用于当前显示类型的枚举
    enum ShowType {
        GameList,       // 场次列表
        PlayerList,     // 队员列表
        PlayerStats,    // 队员统计
    };

protected:
    void resizeEvent(QResizeEvent *event) override;

private slots:
    // 菜单槽函数
    void on_actionOpen_triggered();
    void on_actionSave_triggered();
    void on_actionExit_triggered();
    void on_actionAddGame_triggered();
    void on_actionRemoveGame_triggered();
    void on_actionAddPlayer_triggered();
    void on_actionRemovePlayer_triggered();
    void on_actionShowGameList_triggered();
    void on_actionShowPlayerStats_triggered();
    void on_actionScoringRules_triggered();
    // 表格修改槽函数
    void onTableChanged();

    // 右键菜单
    void onCustomContextMenuRequested(const QPoint &pos);
    void onRemoveGameAction();
    void onRemovePlayerAction();

    void onShowPlayerList(); // 显示队员列表
    void onShowGameList(); // 显示场次列表

    void onSelectionChanged(const QItemSelection &selected, const QItemSelection &deselected);
    void onSearchTextChanged(const QString &text);

private:
    Ui::MainWindow *ui;
    GameInfoTable m_gameInfoTable; // 数据管理
    QStandardItemModel *m_model;   // 表格模型
    ShowType m_currentShowType;    // 当前显示类型
    int m_currentGameIndex;        // 当前选择的场次索引

    int m_selectedGameIndex; // 当前选中的场次索引

    // 右键菜单
    QMenu *m_contextMenu;
    QAction *m_removeGameAction;
    QAction *m_removePlayerAction;
    int m_selectedRow;

    QLineEdit *m_searchEdit;
    QString m_filterText;

    void ApplyFilter();
    void ApplyColorsNoQss();
};

#endif // MAINWINDOW_H
