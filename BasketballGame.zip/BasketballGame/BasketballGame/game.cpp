﻿#include "game.h"
#include <QDataStream>
#pragma execution_character_set("utf-8")

Game::Game()
    : gameId(0)
{
}

QDataStream &operator<<(QDataStream &out, const Game &game)
{
    out << game.gameId << game.gameTime << game.location
        << game.team1Players << game.team2Players;
    return out;
}

QDataStream &operator>>(QDataStream &in, Game &game)
{
    in >> game.gameId >> game.gameTime >> game.location
       >> game.team1Players >> game.team2Players;
    return in;
}
