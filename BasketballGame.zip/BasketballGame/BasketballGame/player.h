﻿#ifndef PLAYER_H
#define PLAYER_H

#include <QString>
#include <QDate>

class QDataStream;

class Player
{
public:
    Player();

    int number;          // 编号
    QString name;        // 姓名
    int age;             // 年龄
    int threePointers;   // 三分球个数
    int rebounds;        // 篮板球个数
    int dunks;           // 扣篮成功次数
    int steals;          // 抢断次数

    // 计算总得分的方法
    int calculateTotalScore() const;

    friend QDataStream &operator<<(QDataStream &out, const Player &player);
    friend QDataStream &operator>>(QDataStream &in, Player &player);
};

#endif // PLAYER_H
