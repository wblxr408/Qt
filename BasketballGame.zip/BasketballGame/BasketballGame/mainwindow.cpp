﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "addgamedialog.h"
#include "addplayerdialog.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QResizeEvent>
#include <QDebug>
#include <QDateTime>
#include <QStandardItemModel>
#include <QMenu>
#include <QAction>
#include <QStatusBar>
#include <QHeaderView>
#include <QItemSelectionModel>
#include <QSet>
#include <QLabel>
#pragma execution_character_set("utf-8")

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_model(new QStandardItemModel(this)),
    m_currentShowType(GameList),
    m_currentGameIndex(-1),
    m_selectedGameIndex(-1),
    m_selectedRow(-1)
{
    ui->setupUi(this);

    // 初始化表格
    ui->tableView->setModel(m_model);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
    ui->tableView->setFocusPolicy(Qt::StrongFocus);

    // 表格视图初始化设置
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableView->setAlternatingRowColors(true);
    ApplyColorsNoQss();

    // 初始化右键菜单
    m_contextMenu = new QMenu(this);
    m_removeGameAction = new QAction(tr("删除场次"), this);
    m_removePlayerAction = new QAction(tr("删除队员"), this);

    m_contextMenu->addAction(m_removeGameAction);
    m_contextMenu->addAction(m_removePlayerAction);

    connect(m_removeGameAction, &QAction::triggered, this, &MainWindow::onRemoveGameAction);
    connect(m_removePlayerAction, &QAction::triggered, this, &MainWindow::onRemovePlayerAction);

    // 连接信号槽
    connect(ui->tableView, &QTableView::customContextMenuRequested,
            this, &MainWindow::onCustomContextMenuRequested);
    connect(ui->tableView->itemDelegate(), &QAbstractItemDelegate::closeEditor,
            this, &MainWindow::onTableChanged);

    // 连接选择变化事件
    connect(ui->tableView->selectionModel(), &QItemSelectionModel::selectionChanged,
            this, &MainWindow::onSelectionChanged);

    // 手动连接查看菜单的信号槽
    connect(ui->actionShowPlayerList, &QAction::triggered,
            this, &MainWindow::onShowPlayerList);
    connect(ui->actionShowGameList, &QAction::triggered,
            this, &MainWindow::onShowGameList);
    connect(ui->actionShowPlayerStats, &QAction::triggered,
            this, &MainWindow::on_actionShowPlayerStats_triggered);

    // 在状态栏添加提示和搜索框
    QLabel *scoreRuleLabel = new QLabel(tr("得分规则: 三分球3分/个, 扣篮2分/次"));
    ui->statusbar->addPermanentWidget(scoreRuleLabel);
    QLabel *searchLabel = new QLabel(tr("  搜索:"));
    ui->statusbar->addPermanentWidget(searchLabel);
    m_searchEdit = new QLineEdit(this);
    m_searchEdit->setPlaceholderText(tr("编号/姓名/地点等 子串匹配"));
    m_searchEdit->setClearButtonEnabled(true);
    ui->statusbar->addPermanentWidget(m_searchEdit, 1);
    connect(m_searchEdit, &QLineEdit::textChanged, this, &MainWindow::onSearchTextChanged);

    // 默认显示场次列表
    ShowGameList();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 修复表格大小调整问题
void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    QSize centralSize = ui->centralwidget->size();
    ui->tableView->setGeometry(0, 0, centralSize.width(), centralSize.height());
}


void MainWindow::onShowPlayerList()
{
    qDebug() << "onShowPlayerList called";
    qDebug() << "当前显示类型:" << m_currentShowType;
    qDebug() << "选中场次索引:" << m_selectedGameIndex;
    qDebug() << "当前场次索引:" << m_currentGameIndex;

    // 只检查选中的场次索引
    if (m_selectedGameIndex == -1) {
        qDebug() << "没有选中场次，显示警告";
        QMessageBox::warning(this, tr("警告"), tr("请先选择一个场次"));
        return;
    }

    // 显示队员列表
    ShowPlayerList(m_selectedGameIndex);
}

void MainWindow::on_actionOpen_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("打开文件"), "", tr("JSON 文件(*.json)"));
    if (!fileName.isEmpty()) {
        m_gameInfoTable.ReadGamesFromJson(fileName);
        ShowGameList();
        statusBar()->showMessage(tr("文件已加载"), 3000);
    }
}

void MainWindow::on_actionSave_triggered()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("保存文件"), "", tr("JSON 文件(*.json)"));
    if (!fileName.isEmpty()) {
        m_gameInfoTable.SaveGamesToJson(fileName);
        statusBar()->showMessage(tr("文件已保存"), 3000);
    }
}

void MainWindow::on_actionExit_triggered()
{
    QApplication::quit();
}

void MainWindow::on_actionAddGame_triggered()
{
    AddGameDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        Game game;
        game.gameId = dlg.GameId();
        game.gameTime = dlg.GameTime();
        game.location = dlg.Location();
        m_gameInfoTable.AddGame(game);
        ShowGameList();
        statusBar()->showMessage(tr("场次已添加"), 3000);
    }
}

void MainWindow::on_actionRemoveGame_triggered()
{
    QModelIndex index = ui->tableView->currentIndex();
    if (index.isValid() && m_currentShowType == GameList) {
        m_gameInfoTable.RemoveGame(index.row());
        ShowGameList();
        statusBar()->showMessage(tr("场次已删除"), 3000);
    } else {
        QMessageBox::warning(this, tr("警告"), tr("请先选择一个场次"));
    }
}

void MainWindow::on_actionAddPlayer_triggered()
{
    if (m_currentShowType != PlayerList) {
        QMessageBox::warning(this, tr("警告"), tr("请在查看队员列表时添加队员"));
        return;
    }

    // 使用当前正在查看的场次索引，而不是表格的当前选择
    if (m_currentGameIndex == -1) {
        QMessageBox::warning(this, tr("警告"), tr("请先选择一个场次"));
        return;
    }

    AddPlayerDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        Game game = m_gameInfoTable.GetGame(m_currentGameIndex);

        Player player;
        player.number = dlg.Number();
        player.name = dlg.Name();
        player.age = dlg.Age();
        player.threePointers = dlg.ThreePointers();
        player.rebounds = dlg.Rebounds();
        player.dunks = dlg.Dunks();
        player.steals = dlg.Steals();

        // 添加到球队1（可根据需要修改）
        game.team1Players.append(player);

        // 使用新的UpdateGame方法，而不是RemoveGame和AddGame
        m_gameInfoTable.UpdateGame(m_currentGameIndex, game);

        ShowPlayerList(m_currentGameIndex);
        statusBar()->showMessage(tr("队员已添加"), 3000);
    }
}

void MainWindow::on_actionRemovePlayer_triggered()
{
    if (m_currentShowType != PlayerList) {
        QMessageBox::warning(this, tr("警告"), tr("请在查看队员列表时删除队员"));
        return;
    }

    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, tr("警告"),tr("请先选择一个队员"));
        return;
    }

    // 获取场次索引（存储在UserRole中，固定从第0列读取）
    int gameIndex = m_model->item(index.row(), 0)->data(Qt::UserRole).toInt();
    int playerIndex = index.row();

    Game game = m_gameInfoTable.GetGame(gameIndex);
    if (playerIndex < game.team1Players.size()) {
        game.team1Players.removeAt(playerIndex);
    } else {
        int team2Index = playerIndex - game.team1Players.size();
        if (team2Index < game.team2Players.size()) {
            game.team2Players.removeAt(team2Index);
        }
    }

    m_gameInfoTable.UpdateGame(gameIndex, game);

    ShowPlayerList(gameIndex);
    statusBar()->showMessage(tr("队员已删除"), 3000);
}

void MainWindow::on_actionShowGameList_triggered()
{
    ShowGameList();
}

void MainWindow::on_actionShowPlayerStats_triggered()
{
    ShowPlayerStats();
}


void MainWindow::onTableChanged()
{
    QModelIndex index = ui->tableView->currentIndex();
    if (!index.isValid()) return;

    if (m_currentShowType == GameList) {
        int row = index.row();
        Game game = m_gameInfoTable.GetGame(row);

        switch (index.column()) {
        case 0: // 编号
            game.gameId = m_model->data(index).toInt();
            break;
        case 1: // 比赛时间
            game.gameTime = QDateTime::fromString(m_model->data(index).toString(), "yyyy-MM-dd hh:mm");
            break;
        case 2: // 比赛地点
            game.location = m_model->data(index).toString();
            break;
        }

        m_gameInfoTable.UpdateGame(row, game); // 更新
    } else if (m_currentShowType == PlayerList) {
        int gameIndex = m_model->item(index.row(), 0)->data(Qt::UserRole).toInt();
        int playerIndex = index.row();

        Game game = m_gameInfoTable.GetGame(gameIndex);
        Player player;

        if (playerIndex < game.team1Players.size()) {
            player = game.team1Players[playerIndex];
        } else {
            int team2Index = playerIndex - game.team1Players.size();
            if (team2Index < game.team2Players.size()) {
                player = game.team2Players[team2Index];
            }
        }
        switch (index.column()) {
        case 0: // 编号
            player.number = m_model->data(index).toInt();
            break;
        case 1: // 姓名
            player.name = m_model->data(index).toString();
            break;
        case 2: // 年龄
            player.age = m_model->data(index).toInt();
            break;
        case 3: // 三分球
            player.threePointers = m_model->data(index).toInt();
            break;
        case 4: // 篮板球
            player.rebounds = m_model->data(index).toInt();
            break;
        case 5: // 扣篮
            player.dunks = m_model->data(index).toInt();
            break;
        case 6: // 抢断
            player.steals = m_model->data(index).toInt();
            break;
        }

        if (playerIndex < game.team1Players.size()) {
            game.team1Players[playerIndex] = player;
        } else {
            int team2Index = playerIndex - game.team1Players.size();
            if (team2Index < game.team2Players.size()) {
                game.team2Players[team2Index] = player;
            }
        }

        m_gameInfoTable.UpdateGame(gameIndex, game); // 更新
    }
}

void MainWindow::onCustomContextMenuRequested(const QPoint &pos)
{
    QModelIndex index = ui->tableView->indexAt(pos);
    if (index.isValid()) {
        m_selectedRow = index.row();
        m_contextMenu->exec(ui->tableView->viewport()->mapToGlobal(pos));
    }
}

void MainWindow::onRemoveGameAction()
{
    if (m_currentShowType == GameList) {
        m_gameInfoTable.RemoveGame(m_selectedRow);
        ShowGameList();
        statusBar()->showMessage(tr("场次已删除"), 3000);
    }
}

void MainWindow::onRemovePlayerAction()
{
    if (m_currentShowType == PlayerList) {
        on_actionRemovePlayer_triggered();
    }
}

void MainWindow::onShowGameList()
{
    ShowGameList();
}

void MainWindow::onSelectionChanged(const QItemSelection &selected, const QItemSelection &deselected)
{
    Q_UNUSED(deselected);
    if (selected.indexes().isEmpty()) {
        m_selectedGameIndex = -1;
        return;
    }
    QModelIndex index = selected.indexes().first();
    if (m_currentShowType == GameList) {
        m_selectedGameIndex = index.row();
    }
}


void MainWindow::ShowGameList()
{
    // 实现场次列表显示
    m_model->clear();
    m_model->setHorizontalHeaderLabels(QStringList() << tr("编号") << tr("比赛时间") << tr("比赛地点"));

    for (int i = 0; i < m_gameInfoTable.GetGameCount(); ++i) {
        Game game = m_gameInfoTable.GetGame(i);
        QList<QStandardItem*> items;
        items << new QStandardItem(QString::number(game.gameId))
              << new QStandardItem(game.gameTime.toString("yyyy-MM-dd hh:mm"))
              << new QStandardItem(game.location);
        m_model->appendRow(items);
    }

    m_currentShowType = GameList;
    m_currentGameIndex = -1;
    ApplyFilter();
}

void MainWindow::ShowPlayerList(int gameIndex)
{
    // 实现队员列表显示
    m_model->clear();
    m_model->setHorizontalHeaderLabels(QStringList() << tr("编号") << tr("姓名") << tr("年龄")
        << tr("三分球") << tr("篮板球") << tr("扣篮") << tr("抢断"));

    Game game = m_gameInfoTable.GetGame(gameIndex);

    // 添加球队1队员
    for (const Player &player : game.team1Players) {
        QList<QStandardItem*> items;
        items << new QStandardItem(QString::number(player.number))
              << new QStandardItem(player.name)
              << new QStandardItem(QString::number(player.age))
              << new QStandardItem(QString::number(player.threePointers))
              << new QStandardItem(QString::number(player.rebounds))
              << new QStandardItem(QString::number(player.dunks))
              << new QStandardItem(QString::number(player.steals));
        QStandardItem *item = items.first();
        item->setData(gameIndex, Qt::UserRole); // 存储场次索引
        m_model->appendRow(items);
    }

    // 添加球队2队员
    for (const Player &player : game.team2Players) {
        QList<QStandardItem*> items;
        items << new QStandardItem(QString::number(player.number))
              << new QStandardItem(player.name)
              << new QStandardItem(QString::number(player.age))
              << new QStandardItem(QString::number(player.threePointers))
              << new QStandardItem(QString::number(player.rebounds))
              << new QStandardItem(QString::number(player.dunks))
              << new QStandardItem(QString::number(player.steals));
        QStandardItem *item = items.first();
        item->setData(gameIndex, Qt::UserRole); // 存储场次索引
        m_model->appendRow(items);
    }

    m_currentShowType = PlayerList;
    m_currentGameIndex = gameIndex;
    ApplyFilter();
}

void MainWindow::ShowPlayerStats()
{
    // 实现队员统计显示
    m_model->clear();
    m_model->setHorizontalHeaderLabels(QStringList() << tr("编号") << tr("姓名")
        << tr("三分球总数") << tr("篮板球总数") << tr("扣篮总数") << tr("抢断总数") << tr("总得分"));

    // 使用GetAllPlayerStats方法获取所有球员的统计数据
    QMap<int, Player> playerStats = m_gameInfoTable.GetAllPlayerStats();

    // 遍历所有球员统计数据
    for (auto it = playerStats.begin(); it != playerStats.end(); ++it) {
        const Player &stats = it.value();
        QList<QStandardItem*> items;
        items << new QStandardItem(QString::number(stats.number))
              << new QStandardItem(stats.name)
              << new QStandardItem(QString::number(stats.threePointers))
              << new QStandardItem(QString::number(stats.rebounds))
              << new QStandardItem(QString::number(stats.dunks))
              << new QStandardItem(QString::number(stats.steals))
              << new QStandardItem(QString::number(stats.calculateTotalScore())); // 添加总得分
        m_model->appendRow(items);
    }

    m_currentShowType = PlayerStats;

    // 显示得分规则提示
    statusBar()->showMessage(tr("得分规则: 三分球3分/个, 扣篮2分/次"), 5000); // 显示5秒
    ApplyFilter();
}

void MainWindow::on_actionScoringRules_triggered()
{
    QMessageBox::information(this, tr("得分规则"),
        tr("当前得分规则：\n"
           "- 三分球：3分/个\n"
           "- 扣篮：2分/次\n"
           "- 篮板球和抢断：不得分"));
}

void MainWindow::onSearchTextChanged(const QString &text)
{
    m_filterText = text;
    ApplyFilter();
}

void MainWindow::ApplyFilter()
{
    if (!ui || !ui->tableView) return;
    const QString needle = m_filterText.trimmed();
    const bool noFilter = needle.isEmpty();
    const int rows = m_model->rowCount();
    const int cols = m_model->columnCount();

    for (int r = 0; r < rows; ++r) {
        bool match = noFilter;
        if (!noFilter) {
            for (int c = 0; c < cols; ++c) {
                QModelIndex idx = m_model->index(r, c);
                QString cell = m_model->data(idx).toString();
                if (cell.contains(needle, Qt::CaseInsensitive)) {
                    match = true;
                    break;
                }
            }
        }
        ui->tableView->setRowHidden(r, !match);
    }

    // 禁用样式表，颜色改由调色板控制
    ui->tableView->setStyleSheet("");
    ApplyColorsNoQss();
}

void MainWindow::ApplyColorsNoQss()
{
    if (!ui || !ui->tableView) return;
    QPalette pal = ui->tableView->palette();
    pal.setColor(QPalette::Base, QColor(248, 249, 250));
    pal.setColor(QPalette::AlternateBase, QColor(240, 243, 247));
    pal.setColor(QPalette::Text, Qt::black);
    pal.setColor(QPalette::WindowText, Qt::black);
    pal.setColor(QPalette::Highlight, QColor(208, 235, 255));
    pal.setColor(QPalette::HighlightedText, Qt::black);
    ui->tableView->setPalette(pal);

    // 表头颜色通过视图的palette影响
    QHeaderView *hh = ui->tableView->horizontalHeader();
    if (hh) {
        QPalette hp = hh->palette();
        hp.setColor(QPalette::Button, QColor(243, 245, 247));
        hp.setColor(QPalette::ButtonText, Qt::black);
        hh->setPalette(hp);
    }

    QHeaderView *vh = ui->tableView->verticalHeader();
    if (vh) {
        QPalette vp = vh->palette();
        vp.setColor(QPalette::Button, QColor(243, 245, 247));
        vp.setColor(QPalette::ButtonText, Qt::black);
        vh->setPalette(vp);
    }
}

