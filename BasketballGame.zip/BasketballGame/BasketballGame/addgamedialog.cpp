﻿#include "addgamedialog.h"
#include "ui_addgamedialog.h"
#pragma execution_character_set("utf-8")

AddGameDialog::AddGameDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddGameDialog)
{
    ui->setupUi(this);
    setWindowTitle(tr("添加场次"));

    // 设置默认时间为当前时间
    ui->dateTimeEdit->setDateTime(QDateTime::currentDateTime());

    // 设置合理的数值范围（添加输入验证）
    ui->spinBoxId->setRange(1, 999);  // 场次编号范围1-999
}

AddGameDialog::~AddGameDialog()
{
    delete ui;
}

int AddGameDialog::GameId() const
{
    return ui->spinBoxId->value();
}

QDateTime AddGameDialog::GameTime() const
{
    return ui->dateTimeEdit->dateTime();
}

QString AddGameDialog::Location() const
{
    return ui->lineEditLocation->text();
}
